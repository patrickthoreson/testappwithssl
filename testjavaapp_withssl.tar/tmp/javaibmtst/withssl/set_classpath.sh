export CLASSPATH=`pwd`/myJar.jar:`pwd`/postgresql-42.2.10.jar:.
